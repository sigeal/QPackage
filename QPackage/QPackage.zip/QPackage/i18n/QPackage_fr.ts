<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>QPackage</name>
    <message>
        <location filename="QPackage.py" line="174"/>
        <source>&amp;QPackage</source>
        <translation></translation>
    </message>
    <message>
        <location filename="QPackage_dialog.py" line="120"/>
        <source>QPackage</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QPackageDialogBase</name>
    <message>
        <location filename="QPackage_dialog_base.py" line="69"/>
        <source>QPackage</source>
        <translation>QPackage</translation>
    </message>
    <message>
        <location filename="QPackage_dialog_base.py" line="70"/>
        <source>Destination folder</source>
        <translation>Répertoire de destination</translation>
    </message>
    <message>
        <location filename="QPackage_dialog_base.py" line="71"/>
        <source>Load layers of the current project</source>
        <translation>Lecture des couches du projet</translation>
    </message>
    <message>
        <location filename="QPackage_dialog_base.py" line="72"/>
        <source>Copy the layers</source>
        <translation>Copier les couches</translation>
    </message>
    <message>
        <location filename="QPackage_dialog_base.py" line="73"/>
        <source>Choose the CRS</source>
        <translation>Choisir le SCR</translation>
    </message>
</context>
<context>
    <name>choosedestination</name>
    <message>
        <location filename="QPackage_dialog.py" line="99"/>
        <source>You must choose the destination directory</source>
        <translation>Vous devez sélectionner un répertoire de destination</translation>
    </message>
</context>
<context>
    <name>mustclose</name>
    <message>
        <location filename="QPackage_dialog.py" line="120"/>
        <source>You must close Qgis to take into account changes</source>
        <translation>Vous devez fermer Qgis pour tenir compte des changements</translation>
    </message>
</context>
<context>
    <name>select destination</name>
    <message>
        <location filename="QPackage_dialog.py" line="49"/>
        <source>Select directory to Fling from...</source>
        <translation>Vous devez sélectionner un répertoire de destination...</translation>
    </message>
</context>
</TS>
